/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.consultorio_fuboca.controle;

import com.mycompany.consultorio_fuboca.dao.ConsultaDAO;
import com.mycompany.consultorio_fuboca.modelo.Consulta;
import java.sql.Date;
import java.sql.Time;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

/**
 *
 * @author aluno.den
 */
public class ConsultaControle {
    private ConsultaDAO dao = new ConsultaDAO();
    private static final DateTimeFormatter FORMATADOR_DATA = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    public void cadastrar(String nomePaciente, String nomeMedico,String dataStr, String horaStr,String observacao ) {
        LocalDate data = LocalDate.parse(dataStr, FORMATADOR_DATA);
        LocalTime hora = LocalTime.parse(horaStr);
        Consulta c = new Consulta(nomePaciente, nomeMedico,data, hora,observacao );
        dao.inserir(c);
    }

    public ArrayList<Consulta> listar() {
        return dao.listar();
    }

    public void atualizar(int idConsulta,String nomePaciente, String nomeMedico ,String dataStr, String horaStr,String observacao ) {
        LocalDate data = LocalDate.parse(dataStr, FORMATADOR_DATA);
        LocalTime hora = LocalTime.parse(horaStr);
        Consulta c = new Consulta(idConsulta,nomePaciente, nomeMedico, data, hora,observacao );
        dao.atualizar(c);
    }

    public void remover(int idConsulta) {
        dao.remover(idConsulta);
    }
    
    public ArrayList<Consulta> buscarPorData(String dataStr) {
        LocalDate data = LocalDate.parse(dataStr, FORMATADOR_DATA);
        return dao.buscarPorData(data);
    }

    /*public void cadastrar(String nomePaciente, String nomeMedico, Date data, Time hora, String observacao) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }*/
}

